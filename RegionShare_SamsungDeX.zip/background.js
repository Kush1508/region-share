/**
 * Region Share - Background Service Worker (Manifest V3)
 * Orchestrates content script injection, popup window creation,
 * context menus, and state synchronization between source tabs and cropped viewer.
 */

const activeSessions = new Map();

// Register context menus on install
chrome.runtime.onInstalled.addListener(() => {
  if (chrome.contextMenus) {
    chrome.contextMenus.removeAll(() => {
      chrome.contextMenus.create({
        id: 'crop-element',
        title: '🎯 Region Share: Crop Element or Area',
        contexts: ['page', 'selection', 'link', 'editable', 'image', 'video']
      });
      chrome.contextMenus.create({
        id: 'open-viewer',
        title: '📺 Region Share: Open Cropped Screen Studio',
        contexts: ['all']
      });
    });
  }
});

// Context menu click listener
if (chrome.contextMenus && chrome.contextMenus.onClicked) {
  chrome.contextMenus.onClicked.addListener(async (info, tab) => {
    if (info.menuItemId === 'crop-element' && tab && tab.id) {
      triggerTabSelection(tab);
    } else if (info.menuItemId === 'open-viewer') {
      handleOpenViewer({
        rect: { x: 100, y: 100, width: 960, height: 540 },
        viewport: { width: 1920, height: 1080 },
        elementTag: 'Screen / Window Cropper'
      }, tab);
    }
  });
}

// Listen for clicks on the extension action icon
chrome.action.onClicked.addListener(triggerTabSelection);

/**
 * Triggers the crop overlay on the active tab
 */
async function triggerTabSelection(tab) {
  if (!tab || !tab.id) return;

  // If on an internal browser page where content scripts cannot run (e.g. chrome:// or new tab),
  // open the Cropped Screen Studio popup directly so the user can crop any screen or window!
  if (
    !tab.url ||
    tab.url.startsWith('chrome://') ||
    tab.url.startsWith('chrome-extension://') ||
    tab.url.startsWith('edge://') ||
    tab.url.startsWith('view-source:') ||
    tab.url.startsWith('about:')
  ) {
    handleOpenViewer({
      rect: { x: 100, y: 100, width: 960, height: 540 },
      viewport: { width: 1920, height: 1080 },
      elementTag: 'Screen / Window Cropper'
    }, tab);
    return;
  }

  try {
    // Attempt to toggle selection if already injected
    await chrome.tabs.sendMessage(tab.id, { action: 'TOGGLE_SELECTION' });
  } catch (err) {
    // Content script not yet active in this tab (e.g. tab opened before extension loaded), inject CSS and JS
    try {
      await chrome.scripting.insertCSS({
        target: { tabId: tab.id },
        files: ['content.css']
      });

      await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        files: ['content.js']
      });

    } catch (injectErr) {
      // Script injection fallback handled
    }
  }
}

// Handle incoming messages from content scripts and viewer popups
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.action === 'OPEN_VIEWER') {
    handleOpenViewer(msg.selection, sender.tab).then(sendResponse);
    return true; // Keep message channel open for async response
  }

  if (msg.action === 'GET_SESSION') {
    const session = activeSessions.get(msg.sessionId);
    sendResponse({ session });
    return false;
  }

  if (msg.action === 'RECT_UPDATE') {
    // Broadcast rect updates to any open viewer popups
    chrome.runtime.sendMessage({
      action: 'VIEWER_RECT_UPDATE',
      tabId: sender.tab ? sender.tab.id : null,
      rect: msg.rect,
      viewport: msg.viewport
    }).catch(() => {
      // Ignored if no viewer is currently listening
    });
    return false;
  }
});

/**
 * Creates a clean, borderless popup window sized proportionally to the cropped area
 */
async function handleOpenViewer(selection, sourceTab) {
  const sessionId = 'rs_' + Date.now() + '_' + Math.random().toString(36).substring(2, 8);
  let streamId = null;
  if (sourceTab && sourceTab.id && chrome.tabCapture && chrome.tabCapture.getMediaStreamId) {
    try {
      streamId = await new Promise((resolve) => {
        chrome.tabCapture.getMediaStreamId({ targetTabId: sourceTab.id }, (id) => {
          if (chrome.runtime.lastError || !id) {
            resolve(null);
          } else {
            resolve(id);
          }
        });
      });
    } catch (e) {
      // streamId fallback
    }
  }

  const sessionData = {
    sessionId,
    streamId,
    sourceTabId: sourceTab ? sourceTab.id : null,
    sourceTabTitle: sourceTab ? (sourceTab.title || 'Selected Tab') : 'Screen / Window Cropper',
    sourceTabUrl: sourceTab ? sourceTab.url : '',
    selection,
    createdAt: Date.now()
  };

  activeSessions.set(sessionId, sessionData);

  // Calculate clean popup dimensions matching crop aspect ratio
  const rect = selection.rect;
  const aspect = (rect.width > 0 && rect.height > 0) ? (rect.width / rect.height) : (16 / 9);

  let targetWidth = Math.round(rect.width);
  // Clamp width to reasonable desktop bounds
  targetWidth = Math.max(560, Math.min(1280, targetWidth));
  let targetHeight = Math.round(targetWidth / aspect);

  // Clamp height
  if (targetHeight < 400) {
    targetHeight = 400;
  } else if (targetHeight > 840) {
    targetHeight = 840;
    targetWidth = Math.round(targetHeight * aspect);
  }

  // Account for minimal popup window frame chrome on OS
  const windowWidth = targetWidth + 16;
  const windowHeight = targetHeight + 36;

  try {
    const popupUrl = chrome.runtime.getURL(`viewer.html?session=${encodeURIComponent(sessionId)}&streamId=${encodeURIComponent(streamId || '')}`);
    const win = await chrome.windows.create({
      url: popupUrl,
      type: 'popup',
      width: windowWidth,
      height: windowHeight,
      focused: true
    });

    sessionData.windowId = win.id;
    return { success: true, sessionId, windowId: win.id };
  } catch (err) {
    return { success: false, error: err.message };
  }
}

// Clean up cached sessions when popup windows are closed
if (chrome.windows && chrome.windows.onRemoved) {
  chrome.windows.onRemoved.addListener((windowId) => {
    for (const [sessionId, data] of activeSessions.entries()) {
      if (data.windowId === windowId) {
        activeSessions.delete(sessionId);
        break;
      }
    }
  });
}
